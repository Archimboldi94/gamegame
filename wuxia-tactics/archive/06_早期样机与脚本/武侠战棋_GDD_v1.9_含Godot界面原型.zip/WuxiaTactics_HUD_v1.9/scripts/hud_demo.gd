extends Control
## B1《渡口截箱》可交互 HUD 样机（不是完整战斗系统）
## 使用真实B1地形与角色起点；简化敌方AI/数值只用于UI交互测试。

const MAP_PATH := "res://data/b1_map.json"
const WALK_DIRS: Array[Vector2i] = [
    Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1),
    Vector2i(-1, 0),                     Vector2i(1, 0),
    Vector2i(-1, 1),  Vector2i(0, 1),  Vector2i(1, 1)
]
const TILE_HALF := Vector2(30.0, 15.0)
const ORIGIN := Vector2(640, 104)
const COLOR_BASE := Color("#6b826f")
const COLOR_WATER := Color("#386779")
const COLOR_WOOD := Color("#9b7d5b")
const COLOR_MUD := Color("#9d8865")
const COLOR_WALL := Color("#3f4a4c")

var board: Array[String] = []
var board_size := Vector2i(12, 12)
var units: Array[Dictionary] = []
var selected_mode := "move"
var current_index := 0
var round_no := 1
var hovered := Vector2i(-999, -999)
var hover_path: Array[Vector2i] = []
var pending_path: Array[Vector2i] = []
var status_text := "移动鼠标到地图格子，点击可用位置。"
var skill_commands := ["普攻", "破风剑", "回锋剑", "截脉指", "燕行步", "防御", "调息"]
var top_bar: PanelContainer
var bottom_bar: PanelContainer
var turn_label: Label
var status_label: Label
var info_label: Label
var detail_panel: PanelContainer
var detail_label: Label
var warning_dialog: ConfirmationDialog
var command_buttons: Dictionary = {}
var command_costs := {"普攻": [3, 0], "破风剑": [4, 3], "回锋剑": [3, 2], "截脉指": [4, 4], "燕行步": [2, 4], "防御": [2, 0], "调息": [3, 0]}

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _load_board()
    _init_units()
    _build_ui()
    _refresh_all()

func _load_board() -> void:
    var file := FileAccess.open(MAP_PATH, FileAccess.READ)
    if file == null:
        push_error("B1 地图数据不存在。")
        return
    var data: Dictionary = JSON.parse_string(file.get_as_text())
    board_size = Vector2i(int(data["width"]), int(data["height"]))
    for line in data["terrain_grid"]:
        board.append(str(line))

func _init_units() -> void:
    units = [
        {"name":"剑客", "side":"player", "pos":Vector2i(2,10),"facing":Vector2i(0,-1),"hp":28,"max_hp":28,"ap":6,"qi":12,"rp":1,"speed":88,"evasion":5},
        {"name":"枪客", "side":"player", "pos":Vector2i(3,10),"facing":Vector2i(0,-1),"hp":34,"max_hp":34,"ap":6,"qi":12,"rp":1,"speed":61,"evasion":4},
        {"name":"拳师", "side":"player", "pos":Vector2i(4,10),"facing":Vector2i(0,-1),"hp":30,"max_hp":30,"ap":6,"qi":12,"rp":1,"speed":50,"evasion":7},
        {"name":"劫客甲", "side":"enemy", "pos":Vector2i(5,7),"facing":Vector2i(0,1),"hp":20,"max_hp":20,"ap":6,"qi":8,"rp":1,"speed":76,"evasion":10},
        {"name":"劫客乙", "side":"enemy", "pos":Vector2i(7,6),"facing":Vector2i(-1,1),"hp":22,"max_hp":22,"ap":6,"qi":8,"rp":1,"speed":45,"evasion":7}
    ]
    units.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["speed"]) > int(b["speed"]))
    current_index = 0

func _style_panel(bg: Color, edge: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = edge
    style.set_border_width_all(1)
    style.set_corner_radius_all(6)
    style.set_content_margin_all(12)
    return style

func _make_label(text_value: String, size: int, tint: Color) -> Label:
    var lbl := Label.new()
    lbl.text = text_value
    lbl.add_theme_font_size_override("font_size", size)
    lbl.add_theme_color_override("font_color", tint)
    return lbl

func _build_ui() -> void:
    top_bar = PanelContainer.new()
    top_bar.position = Vector2(12, 8)
    top_bar.size = Vector2(1256, 70)
    top_bar.add_theme_stylebox_override("panel", _style_panel(Color("#15242deb"), Color("#769090")))
    add_child(top_bar)
    var header := HBoxContainer.new()
    header.add_theme_constant_override("separation", 26)
    top_bar.add_child(header)
    turn_label = _make_label("行动队列", 17, Color("#efe9d6"))
    turn_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(turn_label)
    var obj := _make_label("B1 渡口截箱  |  目标：击败劫客（UI样机）", 15, Color("#c0d9d0"))
    header.add_child(obj)

    bottom_bar = PanelContainer.new()
    bottom_bar.position = Vector2(12, 572)
    bottom_bar.size = Vector2(1256, 136)
    bottom_bar.add_theme_stylebox_override("panel", _style_panel(Color("#15242df3"), Color("#769090")))
    add_child(bottom_bar)
    var bottom_content := VBoxContainer.new()
    bottom_content.add_theme_constant_override("separation", 10)
    bottom_bar.add_child(bottom_content)
    info_label = _make_label("", 16, Color("#f3ead6"))
    bottom_content.add_child(info_label)
    var actions := HBoxContainer.new()
    actions.add_theme_constant_override("separation", 7)
    bottom_content.add_child(actions)
    for command in skill_commands:
        var btn := Button.new()
        btn.text = command
        btn.custom_minimum_size = Vector2(89, 39)
        btn.pressed.connect(_choose_action.bind(command))
        btn.mouse_entered.connect(_show_command_help.bind(command))
        btn.mouse_exited.connect(_on_command_leave)
        actions.add_child(btn)
        command_buttons[command] = btn
    var end_btn := Button.new()
    end_btn.text = "结束行动 [空格]"
    end_btn.custom_minimum_size = Vector2(155,39)
    end_btn.pressed.connect(_end_turn)
    actions.add_child(end_btn)
    command_buttons["结束行动"] = end_btn
    status_label = _make_label("", 13, Color("#b9c8c4"))
    bottom_content.add_child(status_label)

    detail_panel = PanelContainer.new()
    detail_panel.position = Vector2(916, 142)
    detail_panel.size = Vector2(340, 206)
    detail_panel.add_theme_stylebox_override("panel", _style_panel(Color("#162730f4"), Color("#8aa9a2")))
    add_child(detail_panel)
    detail_label = _make_label("", 16, Color("#f0e8d4"))
    detail_panel.add_child(detail_label)
    detail_panel.hide()
    detail_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    detail_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

    warning_dialog = ConfirmationDialog.new()
    warning_dialog.title = "危险移动路径"
    warning_dialog.dialog_text = "此路径可能触发敌人借机攻击。仍要移动吗？"
    warning_dialog.ok_button_text = "仍然移动"
    add_child(warning_dialog)
    warning_dialog.confirmed.connect(_commit_pending_move)

func _active() -> Dictionary:
    return units[current_index]

func _refresh_all() -> void:
    var u := _active()
    var pieces: Array[String] = []
    for i in range(units.size()):
        var unit: Dictionary = units[i]
        if int(unit["hp"]) <= 0:
            continue
        var marker := "▶ " if i == current_index else ""
        pieces.append(marker + str(unit["name"]) + "(" + str(unit["speed"]) + ")")
    turn_label.text = "第%d轮  |  %s" % [round_no, "  →  ".join(PackedStringArray(pieces))]
    info_label.text = "%s    气血 %d/%d    AP %d/6    内力 %d/12    RP %d/1    当前指令：%s" % [u["name"], u["hp"], u["max_hp"], u["ap"], u["qi"], u["rp"], selected_mode]
    status_label.text = status_text
    for command in skill_commands:
        var costs: Array = command_costs[command]
        var btn: Button = command_buttons[command]
        btn.disabled = int(u["ap"]) < int(costs[0]) or int(u["qi"]) < int(costs[1])
        btn.modulate = Color("#eed9a4") if selected_mode == command else Color.WHITE
    queue_redraw()

func _cell_to_pixel(cell: Vector2i) -> Vector2:
    return ORIGIN + Vector2(float(cell.x-cell.y)*TILE_HALF.x, float(cell.x+cell.y)*TILE_HALF.y)

func _pixel_to_cell(point: Vector2) -> Vector2i:
    var p := point - ORIGIN
    var x := (p.x/TILE_HALF.x + p.y/TILE_HALF.y)*0.5
    var y := (p.y/TILE_HALF.y - p.x/TILE_HALF.x)*0.5
    return Vector2i(roundi(x), roundi(y))

func _in_bounds(cell: Vector2i) -> bool:
    return cell.x >= 0 and cell.y >= 0 and cell.x < board_size.x and cell.y < board_size.y

func _tile(cell: Vector2i) -> String:
    if not _in_bounds(cell) or board.is_empty():
        return "#"
    return board[cell.y].substr(cell.x, 1)

func _blocked(cell: Vector2i, include_units: bool=true) -> bool:
    if _tile(cell) in ["#", "~", "C", "h", "H"]:
        return true
    if include_units:
        for u in units:
            if int(u["hp"]) > 0 and u["pos"] == cell:
                return true
    return false

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color("#1d3035"), true)
    for y in range(board_size.y):
        for x in range(board_size.x):
            var cell := Vector2i(x,y)
            var t := _tile(cell)
            var p := _cell_to_pixel(cell)
            var points := PackedVector2Array([
                p+Vector2(0,-TILE_HALF.y), p+Vector2(TILE_HALF.x,0),
                p+Vector2(0,TILE_HALF.y), p+Vector2(-TILE_HALF.x,0)
            ])
            var col := COLOR_BASE
            if t == "~": col = COLOR_WATER
            elif t == "=": col = COLOR_WOOD
            elif t == "m": col = COLOR_MUD
            elif t == "C": col = COLOR_WALL
            elif (x+y)%2==0: col = Color("#799077")
            draw_colored_polygon(points, col)
            draw_polyline(PackedVector2Array([points[0],points[1],points[2],points[3],points[0]]), Color("#293e3c9b"), 1.0)
            if t == "C":
                draw_rect(Rect2(p+Vector2(-13,-24),Vector2(26,18)),Color("#544c43"),true)
            if cell == hovered:
                draw_colored_polygon(points, Color("#d6c36d71"))
                draw_polyline(PackedVector2Array([points[0],points[1],points[2],points[3],points[0]]),Color("#fff2ae"),2.0)
            if cell in hover_path:
                draw_colored_polygon(points,Color("#5fb0e65e"))
    for u in units:
        if int(u["hp"]) <= 0:
            continue
        var p := _cell_to_pixel(u["pos"])
        var enemy := str(u["side"]) == "enemy"
        var c := Color("#b96c5e") if enemy else Color("#69acc9")
        draw_circle(p+Vector2(0,-11),13,c)
        draw_arc(p+Vector2(0,-11),14,0,TAU,24,Color("#e7e3cc"),1.0)
        draw_string(get_theme_default_font(),p+Vector2(-24,-7),str(u["name"]).substr(0,1), HORIZONTAL_ALIGNMENT_CENTER,48,14,Color.WHITE)
        var facing: Vector2i = u["facing"]
        draw_line(p+Vector2(0,-11),p+Vector2(facing.x*12, facing.y*8-11),Color.WHITE,2.0)
    draw_string(get_theme_default_font(),Vector2(20,115),"B1 渡口截箱 · 12×12格 · 地形来自v1.3",HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("#d4e5d8"))
    draw_string(get_theme_default_font(),Vector2(20,141),"蓝色=我方  红色=敌方  木箱=障碍  泥地=2AP",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#c4d0c9"))
    draw_string(get_theme_default_font(),Vector2(20,164),"教学样机：未实现敌方AI及完整战斗规则",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#d6be8f"))

func _find_unit(cell: Vector2i) -> int:
    for i in range(units.size()):
        if int(units[i]["hp"]) > 0 and units[i]["pos"] == cell:
            return i
    return -1

func _find_path(start: Vector2i, goal: Vector2i) -> Array[Vector2i]:
    var result: Array[Vector2i] = []
    if start == goal or _blocked(goal):
        return result
    var frontier: Array[Vector2i] = [start]
    var distances: Dictionary = {start: 0}
    var previous: Dictionary = {}
    while not frontier.is_empty():
        var best_index := 0
        for i in range(1,frontier.size()):
            if int(distances[frontier[i]]) < int(distances[frontier[best_index]]):
                best_index = i
        var cur := frontier[best_index]
        frontier.remove_at(best_index)
        if cur == goal:
            break
        for offset in WALK_DIRS:
            var nxt: Vector2i = cur + offset
            if _blocked(nxt):
                continue
            if offset.x != 0 and offset.y != 0:
                if _blocked(Vector2i(cur.x+offset.x, cur.y),false) and _blocked(Vector2i(cur.x,cur.y+offset.y),false):
                    continue
            var cost := 2 if _tile(nxt) == "m" else 1
            var score: int = int(distances[cur]) + cost
            if not distances.has(nxt) or score < int(distances[nxt]):
                distances[nxt] = score
                previous[nxt] = cur
                if nxt not in frontier:
                    frontier.append(nxt)
    if not distances.has(goal):
        return result
    var cur := goal
    while cur != start:
        result.push_front(cur)
        cur = previous[cur]
    return result

func _path_cost(path: Array[Vector2i]) -> int:
    var value := 0
    for step in path:
        value += 2 if _tile(step) == "m" else 1
    return value

func _under_enemy_control(cell: Vector2i, enemy: Dictionary) -> bool:
    var e_pos: Vector2i = enemy["pos"]
    var delta: Vector2i = cell - e_pos
    if maxi(absi(delta.x),absi(delta.y)) != 1:
        return false
    var f: Vector2i = enemy["facing"]
    return delta.x*f.x + delta.y*f.y >= 0

func _danger_sources(path: Array[Vector2i]) -> Array[String]:
    var result: Array[String] = []
    var from_cell: Vector2i = _active()["pos"]
    for cell in path:
        for e in units:
            if str(e["side"]) != "enemy" or int(e["hp"]) <= 0 or int(e["rp"]) <= 0:
                continue
            if _under_enemy_control(from_cell,e) and not _under_enemy_control(cell,e):
                if str(e["name"]) not in result:
                    result.append(str(e["name"]))
        from_cell = cell
    return result

func _attack_preview(target: Dictionary) -> String:
    var hit: int = clampi(90+5-int(target["evasion"]),10,95)
    var damage: int = 8
    var ap: int = 3
    var qi: int = 0
    if selected_mode == "破风剑":
        hit = clampi(hit-5,10,95)
        damage = 11
        ap = 4
        qi = 3
    elif selected_mode == "回锋剑":
        damage = 9
        ap = 3
        qi = 2
    elif selected_mode == "截脉指":
        damage = 5
        ap = 4
        qi = 4
    return "%s → %s\n命中率：%d%%\n命中后伤害：%d\n消耗：%d AP / %d内力\n目标RP：%d / 1\n提示：数值为UI演示用" % [selected_mode,target["name"],hit,damage,ap,qi,target["rp"]]

func _is_attack_mode() -> bool:
    return selected_mode in ["普攻", "破风剑", "回锋剑", "截脉指"]

func _attack_reaches(cell: Vector2i) -> bool:
    var at: Vector2i = _active()["pos"]
    var dx: int = absi(cell.x-at.x)
    var dy: int = absi(cell.y-at.y)
    if selected_mode == "破风剑":
        return maxi(dx,dy) <= 3 and (dx == 0 or dy == 0 or dx == dy)
    if selected_mode == "截脉指":
        return maxi(dx,dy) <= 2
    return maxi(dx,dy) == 1

func _update_hover(cell: Vector2i) -> void:
    hovered = cell
    hover_path.clear()
    if not _in_bounds(cell):
        detail_panel.hide()
        queue_redraw()
        return
    var enemy_i: int = _find_unit(cell)
    if _is_attack_mode() and enemy_i >= 0 and str(units[enemy_i]["side"]) == "enemy":
        detail_label.text = _attack_preview(units[enemy_i]) if _attack_reaches(cell) else "目标超出当前武学射程。"
        detail_panel.show()
    elif selected_mode == "move":
        var p: Array[Vector2i] = _find_path(_active()["pos"],cell)
        hover_path = p
        if not p.is_empty():
            var cost := _path_cost(p)
            var danger := _danger_sources(p)
            detail_label.text = "移动预览\n目标格：%s\nAP消耗：%d / 剩余%d\n%s" % [str(cell),cost,_active()["ap"],"警告：可能遭%s借机攻击" % [",".join(danger)] if not danger.is_empty() else "路径安全（演示判定）"]
            detail_panel.show()
        else:
            detail_panel.hide()
    else:
        detail_panel.hide()
    queue_redraw()

func _process(_delta: float) -> void:
    var pos := get_viewport().get_mouse_position()
    if pos.y >= 565 or pos.y <= 85:
        return
    var cell := _pixel_to_cell(pos)
    if cell != hovered:
        _update_hover(cell)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_ESCAPE: _cancel_action()
            KEY_SPACE: _end_turn()
            KEY_1: _choose_action("破风剑")
            KEY_2: _choose_action("回锋剑")
            KEY_3: _choose_action("截脉指")
            KEY_Q: _choose_action("普攻")
            KEY_E: _choose_action("燕行步")
            KEY_F: _choose_action("防御")
            KEY_R: _choose_action("调息")
            KEY_M: _choose_action("move")
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_RIGHT:
            _cancel_action()
        elif event.button_index == MOUSE_BUTTON_LEFT:
            var click: Vector2 = event.position
            if click.y <= 85 or click.y >= 565:
                return
            _submit_cell(_pixel_to_cell(click))

func _choose_action(action: String) -> void:
    if not (action in skill_commands or action == "move"):
        return
    if command_costs.has(action):
        var costs: Array = command_costs[action]
        if int(_active()["ap"]) < int(costs[0]) or int(_active()["qi"]) < int(costs[1]):
            status_text = "资源不足，不能选择%s。" % action
            _refresh_all()
            return
    selected_mode = action
    if action == "防御" or action == "调息":
        _resolve_self_action(action)
    else:
        status_text = "选择%s：悬停格子或目标可查看预览；右键取消。" % action
        if _in_bounds(hovered):
            _update_hover(hovered)
    _refresh_all()

func _resolve_self_action(action: String) -> void:
    var u := _active()
    var costs: Array = command_costs[action]
    u["ap"] = int(u["ap"]) - int(costs[0])
    if action == "调息":
        u["qi"] = mini(12,int(u["qi"])+4)
        status_text = "已调息：恢复4点内力（演示）。"
    else:
        status_text = "已进入防御姿态（演示：未实现正式减伤状态）。"
    selected_mode = "move"

func _show_command_help(action: String) -> void:
    if not command_costs.has(action):
        return
    var costs: Array = command_costs[action]
    detail_label.text = "%s\nAP消耗：%d\n内力消耗：%d\n\n点击选择指令，悬停地图格子预览。" % [action,costs[0],costs[1]]
    detail_panel.show()

func _on_command_leave() -> void:
    if _in_bounds(hovered):
        _update_hover(hovered)
    else:
        detail_panel.hide()

func _submit_cell(cell: Vector2i) -> void:
    if not _in_bounds(cell):
        return
    var u := _active()
    var enemy_i := _find_unit(cell)
    if _is_attack_mode() and enemy_i >= 0 and str(units[enemy_i]["side"]) == "enemy":
        if not _attack_reaches(cell):
            status_text = "目标超出范围。"
        else:
            var costs: Array = command_costs[selected_mode]
            if int(u["ap"]) < int(costs[0]) or int(u["qi"]) < int(costs[1]):
                status_text = "AP或内力不足。"
            else:
                var target: Dictionary = units[enemy_i]
                var odds: int = clampi(90+5-int(target["evasion"])-(5 if selected_mode == "破风剑" else 0),10,95)
                u["ap"] = int(u["ap"]) - int(costs[0])
                u["qi"] = int(u["qi"]) - int(costs[1])
                if randf()*100.0 < float(odds):
                    var dmg := 11 if selected_mode == "破风剑" else (9 if selected_mode == "回锋剑" else (5 if selected_mode == "截脉指" else 8))
                    target["hp"] = maxi(0,int(target["hp"])-dmg)
                    status_text = "%s命中%s，造成%d伤害（UI演示结算）。" % [selected_mode,target["name"],dmg]
                else:
                    status_text = "%s未命中，资源已消耗（UI演示结算）。" % selected_mode
                selected_mode = "move"
    elif selected_mode == "move":
        var p: Array[Vector2i] = _find_path(u["pos"],cell)
        var cost: int = _path_cost(p)
        if p.is_empty() or cost > int(u["ap"]):
            status_text = "此格不可达，或AP不足。"
        elif not _danger_sources(p).is_empty():
            pending_path = p
            warning_dialog.dialog_text = "离开敌方控制区，可能受到借机攻击：%s。仍要移动吗？\n提示：风险结算尚未实现，此处仅演示确认流程。" % ",".join(_danger_sources(p))
            warning_dialog.popup_centered()
            status_text = "危险移动等待确认；取消不会扣除AP。"
        else:
            _commit_move(p)
    elif selected_mode == "燕行步":
        if not _blocked(cell) and maxi(absi(cell.x-u["pos"].x),absi(cell.y-u["pos"].y)) <= 3:
            u["ap"] = int(u["ap"]) - 2
            u["qi"] = int(u["qi"]) - 4
            u["pos"] = cell
            status_text = "燕行步完成移动（演示：矮墙跳跃与复杂阻挡尚未实现）。"
            selected_mode = "move"
        else:
            status_text = "目标不合法或超出轻功范围。"
    hover_path.clear()
    _refresh_all()
    if _in_bounds(hovered):
        _update_hover(hovered)

func _commit_pending_move() -> void:
    if not pending_path.is_empty():
        _commit_move(pending_path)
    pending_path.clear()
    _refresh_all()

func _commit_move(p: Array[Vector2i]) -> void:
    if p.is_empty():
        return
    var u := _active()
    var cost := _path_cost(p)
    if cost > int(u["ap"]):
        return
    var start: Vector2i = u["pos"]
    var finish: Vector2i = p.back()
    u["ap"] = int(u["ap"]) - cost
    u["pos"] = finish
    var delta: Vector2i = finish - start
    u["facing"] = Vector2i(signi(delta.x),signi(delta.y))
    status_text = "移动到%s，消耗%d AP；借机攻击仅警示，未执行伤害结算。" % [str(finish),cost]
    hover_path.clear()

func _cancel_action() -> void:
    selected_mode = "move"
    pending_path.clear()
    hover_path.clear()
    status_text = "已取消指令；已执行的行动不会撤销。"
    detail_panel.hide()
    _refresh_all()

func _end_turn() -> void:
    var turns := 0
    while turns < units.size():
        current_index += 1
        if current_index >= units.size():
            current_index = 0
            round_no += 1
            for u in units:
                u["rp"] = 1
        if int(_active()["hp"]) > 0 and str(_active()["side"]) == "player":
            _active()["ap"] = 6
            _active()["qi"] = mini(12,int(_active()["qi"])+1)
            break
        turns += 1
    selected_mode = "move"
    pending_path.clear()
    hover_path.clear()
    detail_panel.hide()
    status_text = "已切换到%s。演示版跳过敌方AI；实际游戏应按速度顺序执行敌人行动。" % _active()["name"]
    _refresh_all()
